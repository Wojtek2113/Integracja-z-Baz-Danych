import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class SystemPracownikow extends JFrame {

    private JTextField txtImie;
    private JTextField txtNazwisko;
    private JTextField txtStanowisko;
    private JButton btnDodaj;
    private JTable tabela;
    private DefaultTableModel modelTabeli;

    private String url = "jdbc:sqlite:pracownicy.db";
    private String user = "root";
    private String password = "";

    public SystemPracownikow() {
        setTitle("System Obslugi Pracownikow");
        setSize(650, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        JPanel panelFormularza = new JPanel(new GridLayout(4, 2, 5, 5));
        panelFormularza.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        panelFormularza.add(new JLabel("Imie:"));
        txtImie = new JTextField();
        panelFormularza.add(txtImie);

        panelFormularza.add(new JLabel("Nazwisko:"));
        txtNazwisko = new JTextField();
        panelFormularza.add(txtNazwisko);

        panelFormularza.add(new JLabel("Stanowisko:"));
        txtStanowisko = new JTextField();
        panelFormularza.add(txtStanowisko);

        btnDodaj = new JButton("Dodaj Pracownika");
        panelFormularza.add(new JLabel(""));
        panelFormularza.add(btnDodaj);

        add(panelFormularza, BorderLayout.NORTH);

        String[] kolumny = {"ID", "Imie", "Nazwisko", "Stanowisko"};
        modelTabeli = new DefaultTableModel(kolumny, 0);
        tabela = new JTable(modelTabeli);
        JScrollPane scrollPane = new JScrollPane(tabela);

        add(scrollPane, BorderLayout.CENTER);

        btnDodaj.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dodajPracownika();
            }
        });

        wczytajDane();
    }

    private void wczytajDane() {
        modelTabeli.setRowCount(0);
        String query = "SELECT id, imie, nazwisko, stanowisko FROM pracownicy";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("id");
                String imie = rs.getString("imie");
                String nazwisko = rs.getString("nazwisko");
                String stanowisko = rs.getString("stanowisko");

                modelTabeli.addRow(new Object[]{id, imie, nazwisko, stanowisko});
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Blad bazy danych: " + ex.getMessage(), "Blad", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void dodajPracownika() {
        String imie = txtImie.getText().trim();
        String nazwisko = txtNazwisko.getText().trim();
        String stanowisko = txtStanowisko.getText().trim();

        if (imie.isEmpty() || nazwisko.isEmpty() || stanowisko.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Wszystkie pola musza byc wypelnione!", "Blad walidacji", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String query = "INSERT INTO pracownicy (imie, nazwisko, stanowisko) VALUES (?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, imie);
            stmt.setString(2, nazwisko);
            stmt.setString(3, stanowisko);

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(this, "Pracownik zostal dodany pomyslnie!", "Sukces", JOptionPane.INFORMATION_MESSAGE);

            txtImie.setText("");
            txtNazwisko.setText("");
            txtStanowisko.setText("");

            wczytajDane();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Blad podczas dodawania pracownika: " + ex.getMessage(), "Blad", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new SystemPracownikow().setVisible(true);
            }
        });
    }
}